import socket
import sys
import struct



server_addr = (sys.argv[1], int(sys.argv[2]))  

sendPacker = struct.Struct("6s 15s") 
send2Packer = struct.Struct("6s 12s") 
replyPacker = struct.Struct("10s")
catID = struct.Struct("10s")

neptun = "IOSDX4".encode()
searched = "XWEF3YA0CKHVHN5".encode()
CAT_DICTIONARY = {'ELECT-012': 'Electronics','BO-9037': 'Books','OFF-1056': 'Office','SPT-64': 'Sports','HM-383': 'Home'} 


with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:   
    client.connect(server_addr)
    client.sendall(sendPacker.pack(neptun, searched))
    data = client.recv(128)
    cat = replyPacker.unpack(data)
    cat.decode().strip('\x00')
    category = CAT_DICTIONARY[cat]
    client.sendall(send2Packer.pack(neptun, category))
    data = client.recv(128)
    cat = catID.unpack(data)
    print(cat)



