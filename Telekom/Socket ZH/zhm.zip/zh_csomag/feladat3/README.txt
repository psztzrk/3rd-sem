Ide kerül a 3. feladat megoldása, ezzel a fájlnévvel:

  proxy.py         indítás: python proxy.py <port> <tcp_port> <udp_port>   (a szerverek: TCP 20002, UDP 20003)

Ellenőrzés egy paranccsal, a csomag mappájából (ahol a tests.py van):
  python tests.py check <KÓD> feladat3        (a <KÓD> a feladat Moodle kérdésében szerepel)

A programok minden adatot parancssori paraméterként kapnak (sys.argv), input() nélkül.
