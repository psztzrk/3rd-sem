// Magyar nevekhez az index.html-ben dataEN.js helyett data.js-t tölts be!
// For Hungarian names, load data.js instead of dataEN.js in index.html.

// Delegált eseménykezelés (az előadásból) / Delegated event handling (from the lecture)
function delegate(parent, type, selector, handler) {
  parent.addEventListener(type, function (event) {
    const targetElement = event.target.closest(selector);

    if (this.contains(targetElement)) {
      handler.call(targetElement, event);
    }
  });
}

// Távolság: millió km → pixel / Distance: million km → pixels
function distanceToPx(distance) {
  return Math.round(Math.sqrt(distance) * 7);
}

// Átmérő: km → pixel / Diameter: km → pixels
function diameterToPx(diameter) {
  return Math.round(Math.sqrt(diameter) / 12) + 5;
}

// Az oldal elemei / Elements of the page
const inputFields = document.querySelector("#input-fields");
const planetsDiv = document.querySelector("#planets");

// Ide írd a megoldásodat! / Write your solution here!
