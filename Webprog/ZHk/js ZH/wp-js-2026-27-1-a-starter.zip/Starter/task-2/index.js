// A szonda aktuális helyzete / Current position of the probe
let probeRow = 0
let probeCol = 0

// A táblázat adott sorában és oszlopában lévő cella / The cell in the given row and column of the table
function getCell(row, col) {
  return document.querySelector('#sector').rows[row].cells[col]
}

// Az oldal elemei / Elements of the page
const targetInput = document.querySelector('#target-input')
const addTargetButton = document.querySelector('#add-target')
const route = document.querySelector('#route')
const routeCount = document.querySelector('#route-count')
const probeSelect = document.querySelector('#probe-select')
const probeImage = document.querySelector('#probe-image')
const sector = document.querySelector('#sector')
const moveUpButton = document.querySelector('#move-up')
const moveDownButton = document.querySelector('#move-down')
const moveLeftButton = document.querySelector('#move-left')
const moveRightButton = document.querySelector('#move-right')
const missionStatus = document.querySelector('#status')
